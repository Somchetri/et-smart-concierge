# Architecture

Frontend → Backend → AI Service
