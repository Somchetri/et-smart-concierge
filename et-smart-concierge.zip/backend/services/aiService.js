async function getAIResponse(message) {
  if (message.toLowerCase().includes("invest")) {
    return "Based on your goals, consider mutual funds or SIPs.";
  }

  if (message.toLowerCase().includes("insurance")) {
    return "You may need health and life insurance coverage.";
  }

  return "Tell me more about your financial goals.";
}

module.exports = { getAIResponse };
